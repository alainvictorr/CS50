name=input("Name: ")
print()
print(name)