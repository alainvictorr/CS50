name="Harry"
names=["alain","jorge","alberto"]

print(name[0])
print(names[1])

coordinateX=10.0
coordinateY=20.0

point=(10.0,20.0)
print(point)   

