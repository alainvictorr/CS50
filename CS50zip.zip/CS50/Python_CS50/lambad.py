people=[
    {"name":"Jose","house":"Huanta"},
    {"name":"Alain","house":"Surco"},
    {"name":"Alberto","house":"Linsidro"}
]
def f(person):
    return person["name"]

people.sort(key=f)
print(people)

#otra forma si usar la funcion f sino lambda
people2=[
    {"name":"Jose","house":"Huanta"},
    {"name":"Alain","house":"Surco"},
    {"name":"Alberto","house":"Linsidro"}
]
people2.sort(key=lambda person:person["name"])
print(people2)