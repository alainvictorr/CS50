def complex_function(x,y,z):
    return x+y*z