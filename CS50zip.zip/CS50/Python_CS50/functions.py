from complex_function import complex_function

for i in range(4):
    result=complex_function(i,i+1,i+2)
    print(result)

#print(complex_function(1,2,3))