#create empty set

s=set()

#add element
s.add(1)
s.add(2)
s.add(3)
s.add(4)
s.add(3)
s.remove(2)


print(s)
print(len(s))