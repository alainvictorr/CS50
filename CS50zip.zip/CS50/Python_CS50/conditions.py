n = int(input("Number: "))
if n>0:
    print("n is positive")
elif n==0:
    print("n is zero")
else:
    print("n is negative")
